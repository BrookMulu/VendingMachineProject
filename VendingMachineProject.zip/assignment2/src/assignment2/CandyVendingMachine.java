/*
 * I would like to credit segni with helping me with this class. 
 */
package assignment2;
import java.util.*;
import java.lang.Cloneable; 
import java.text.NumberFormat;

/*
 * @author bgebreey
 *This class creates the vending machine 
 */
public class CandyVendingMachine implements ICandyVendingMachine {
    NumberFormat formatter = NumberFormat.getCurrencyInstance();
    /*
    *the following objects construct the individual items.
    */
    protected Queue <Candy> skittles = new LinkedList();
    protected Queue <Candy> snickers = new LinkedList();
    protected Queue <Candy> MnM = new LinkedList();
    /*
    *the following variables define the different properties of the items.
    */
    public String name;
    public double price;
    public double money;
    public int quantity;
    /*
    *this method returns the money that is present.
    */
    protected double getMoney(){
        return money;
    }
    /*
    *@param aMoney.
    *this method returns the money that is present.
    */
    public void setMoney(Double aMoney){
        money = aMoney;
    }
    /*
    *@param aMoney
    *This method adds money. 
    */
    public void addMoney(Double aMoney){
        money = money + aMoney;
    }
    /*
    *this method gets the quantity.
    */
    public int getQuantity(){
        return quantity;
    }
    /*
    *@aParam aQuantity
    *this method sets the quantity
    */
    public void setQuantity(int aQuantity){
        quantity = aQuantity;
    }
    /*
    *this method gets the name of the item.
    */
    public String getName(){
        return name;
    }
    /*
    *@param aName
    *this method sets the name.
    */
    public void setName(String aName){
        name=aName;
    }
    /*
    *this method gets the price.
    */
    public double getPrice(){
        return price;
    }
    /*
    *@aParam aPrice 
    *this method sets the price
    */
    public void setPrice(double aPrice){
        price=aPrice;
    }
    /*
    *@param money sets the money of each item
    */
    public CandyVendingMachine(double money) throws CloneNotSupportedException{
        Candy sk = new Candy("skittles",4.2);
        for(int i=1;i<=2;i++){
            skittles.add((Candy) sk.clone());
        }
        Candy sn = new Candy("snickers",1.42);
        for(int i=1;i<=5;i++){
            snickers.add((Candy) sn.clone());
        }
        Candy mnm = new Candy("M&M",42.42);
        for(int i=1;i<=2;i++){
            MnM.add((Candy) mnm.clone());
        }
        setMoney(money);

    }
    /*
    *@param aName sets the name of each item.
    *@param aPrice sets the price of each item.
    */
    public CandyVendingMachine(String aName, int aPrice){
        setName(name);
        setPrice(price);
    }
    Scanner in = new Scanner(System.in);
    /*
    *@param stockItem each item.
    *this method sets the quantity, name and price of each item.
    */
    
    public String stock(Queue<Candy> stockItem){
        if(stockItem.size()<=0){
            System.out.println("the item is not available.");
        }
        else{
            System.out.print(stockItem.peek().getName()+ " "+ stockItem.size()+ " - "+stockItem.peek().getName());
        }
        return null;
    }
    @Override
    public String DisplayContents(){
        System.out.println("Here are your options: ");
        if(!skittles.isEmpty()){
            System.out.println("A: " + skittles.peek().getName()+ " ("+skittles.size() + ") " + skittles.peek().getPrice());
        }
        if(!snickers.isEmpty()){
            System.out.println("B: " + snickers.peek().getName()+ " ("+snickers.size() + ") " + snickers.peek().getPrice());
        }
        if(!MnM.isEmpty()){
            System.out.println("C: " + MnM.peek().getName()+ " ("+MnM.size() + ") " + MnM.peek().getPrice());
        }
        return null;
    }
    /*
    *@param slotCode is code of each item in the vending machine.
    *this method allows for each item to be vended.
    */
    @Override
    public Object VendItem(String slotCode){
        if(slotCode.equals("A")&& skittles.size()>0){
            System.out.println(" Here is your "+skittles.peek().getName());
            for(int i = 1; i<=quantity;i++){
                skittles.poll();
            }
        }
        else if(slotCode.equals("A")&&quantity>skittles.size()){
            System.out.println("There are only "+skittles.size()+ " Left. Please enter a quantity below "+ skittles.size()+".");
        }
        if(slotCode.equals("B")&& snickers.size()>0){
            System.out.println(" Here is your "+snickers.peek().getName());
            for(int i = 1; i<=quantity;i++){
                snickers.poll();
            }
        }
        else if(slotCode.equals("B")&&quantity>snickers.size()){
            System.out.println("There are only "+snickers.size()+ " Left. Please enter a quantity below "+ snickers.size()+".");
        }
        if(slotCode.equals("C")&& MnM.size()>0){
            System.out.println(" Here is your "+MnM.peek().getName());
            for(int i = 1; i<=quantity;i++){
                MnM.poll();
            }
        }
        else if(slotCode.equals("c")&&quantity>MnM.size()){
            System.out.println("There are only "+MnM.size()+ " Left. Please enter a quantity below "+ MnM.size()+".");
        }
        return null;
    }
   /*
    *@param amount the amount of money to be taken.
    *This method takes money from the user.
    */
   @Override 
   public void TakeMoney(double amount){
       addMoney(amount);
       System.out.println("Thank you for your purchase!");
    }
    /*
    *@param amount of money to be returned.
    *This method returns money to the user.
    */
    @Override
    public void ReturnMoney(double amount){
        addMoney(-amount);
        System.out.println("Here is your change back" + amount);
    }
    /*
    *@param amount the amount of change to be returned.
    *This method returns change to the user.
    */
    public void returnChange(double amount){
        addMoney(-amount);
        System.out.println("Here is you change back: " + formatter.format(amount)+ " .");
    }
    /*
    *gets the info from the machine.
    */
    @Override
    public String GetMachineInfo() {
        DisplayContents();
        throw new UnsupportedOperationException("Not supported yet.");
    } 
}
