/*
 * I would like to credit Segni with helping with this class.
 */
package assignment2;

/**
 *@author bgebreey
 * This class creates the properties for the candies.
 */
public class Candy implements Cloneable {
    /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author bgebreey
 */
    /*
    *the following lines of code are the variables and thier respective methods that define the different properties of the vending machine.
    */
    public String name;
    public double price;
    public String info;
    /*
    *this method gets the name of the item.
    */
    public String getName(){
        return name;
    }
    /*
    *this method sets the name of the item.
    *@param aName name of the product.
    */
    public void setName(String aName){
        name=aName;
    }
    /*
    *this method gets the price of the item.
    */
    public double getPrice(){
        return price;
    }
     /*
    *this method sets the price of the item.
    *@param aPrice name of the product.
    */
    public void setPrice(double aPrice){
        price=aPrice;
    }
    /*
    *this method gets the information of the product.
    */
    public String getInfo(){
        return name + price;
    }
    /*
    *this mehod sets the information of the product.
    *@param val is both the name and price of the item.
    */
    public void setInfo(String val){
        info = val;
    }
    
    public Candy(){
        
    }
    /*
    @param aName name of item
    @param aPrice price of item
    */
    public Candy(String aName, double aPrice){
        setName(aName);
        setPrice(aPrice);
    }
    /*
    *this method throws an excpetion if the clone does not work.
    */
    public Candy clone() throws CloneNotSupportedException{
        return (Candy) super.clone();
    }
    
}

