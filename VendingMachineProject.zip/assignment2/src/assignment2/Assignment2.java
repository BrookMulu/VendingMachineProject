/*
 * I would like to credit Segni for helping me with this class. 
 */
package assignment2;
import java.util.*;
import java.text.NumberFormat;
/**
 * @author bgebreey
 * this class executes the vending machine. 
 */
public class Assignment2 {
    /*
    *@param value to be converted
    *Converts string represention of a number into a integer.
    */
    public static int tryParsingInt(String val){
        try{
            return Integer.parseInt(val);
        }
        catch(NumberFormatException DN){
            return 0;
        }
    }
     /*
    *@param value to be converted
    *Converts string represention of a number into a double. 
    */
    public static double tryParsingDouble(String val){
        try{
            return Double.parseDouble(val);
        }
        catch(NumberFormatException DN){
            return 0.0;
        }
    }
    /*
    *@param price, price of item to be processed.
    *@param quantity, quantity of item to be processed.
    *@Param vendingMachine, the vending machine to be used.
    *@param formatter, formats the price and quantity.
    *@param slotCode, code of each item.
    *Processes the vending machine transcation.
    */
    public static void processing(Double price, int quantity, CandyVendingMachine vendingMachine, NumberFormat formatter, String slotCode){
        Scanner in = new Scanner(System.in);
        System.out.println("Enter the quantity you want to purchase: ");
        String val = in.nextLine().trim();
        int quantityNeeded = tryParsingInt(val);
        while(quantityNeeded==0){
            System.out.println("The number entered is not a valid number.");
            System.out.println("For it to be valid the value of the number has to be a number greater than 0.");
            System.out.println("Please try again!");
            val = in.nextLine().trim();
            quantityNeeded= tryParsingInt(val);
        }
        String reChoice = "";
        while(quantity<0||quantityNeeded<0||quantityNeeded>quantity){
            System.out.println("The quantity demanded is not possible.");
            System.out.println("The vendingMachine only has "+quantity+" of the item");
            System.out.println("Try again!");
            System.out.println("Please enter the quantity you want to purchase: ");
            reChoice = in.nextLine().toUpperCase().trim();
            if(reChoice.equals("Q")){
                break;
            }
            quantityNeeded = tryParsingInt(reChoice);
        }
        if(!reChoice.equals("Q")){
            vendingMachine.setQuantity(quantityNeeded);
            Double totalCost = quantityNeeded*price;
            System.out.println("Your total cost is "+ formatter.format(totalCost) + " .");
            System.out.println("Insert your payment: ");
            String reChoice2 = in.nextLine().trim();
            Double payment = tryParsingDouble(reChoice2);
            vendingMachine.TakeMoney(payment);
            while(payment<totalCost){
                System.out.println("Not enough funds. Please insert at least an additional "+ formatter.format(totalCost-payment)+ " or click 'Q' to quit. ");
                String purchase = in.nextLine().trim();
                if(purchase.toUpperCase().equals("Q")){
                    vendingMachine.ReturnMoney(payment);
                    System.exit(0);
                }
                else{
                    Double extraPurchase = tryParsingDouble(purchase);
                    payment=payment+extraPurchase;
                    vendingMachine.addMoney(extraPurchase);
                }
            }
            vendingMachine.VendItem(slotCode);
            double change = payment - totalCost;
            if(change>0){
                vendingMachine.returnChange(change);
            }
            System.out.println("Thank you for using the vending Machine.Please come back!");
            System.out.println("The machine has stored " + formatter.format(vendingMachine.getMoney())+".");
            
        }
    }
    /**
     * @param args the command line arguments
     * executes the program.
     */
    public static void main(String[] args)throws CloneNotSupportedException, NumberFormatException, NullPointerException {
        NumberFormat formatter = NumberFormat.getCurrencyInstance();
        CandyVendingMachine vendingMachine = new CandyVendingMachine(150.0);
        //vendingMachine = new CandyVendingMachine(150.0);
        int quantity = 0;
        Double price = null;
        boolean numberOfTimes = true;
        String choice = "";
        Scanner in= new Scanner(System.in);
        while(!choice.toUpperCase().equals("Q")){
            System.out.println(" --------------------------------------------------");
            System.out.println("|                 main Menu                        |");
            System.out.println("|                                                  |");
            System.out.println("|      Do you want to use the Vending Machine?     |");
            System.out.println("|          Y: for Continue                         |");
            System.out.println("|          Q: for Quiting                          |");
            System.out.println(" --------------------------------------------------");
            choice = in.nextLine().toUpperCase().trim();
            
        
        switch(choice){
            case "Y":
                String slotCode = "";
                while(!slotCode.equals("Q")){
                    vendingMachine.DisplayContents();
                    System.out.println("Q. Go Back");
                    slotCode = in.nextLine().trim().toUpperCase();
                    switch(slotCode){
                        case "A": 
                            if(vendingMachine.skittles.isEmpty()){
                                System.out.println("Please choose another Item. Your item selected is not available.");
                            }
                            else{
                                price = vendingMachine.skittles.peek().getPrice();
                                quantity = vendingMachine.skittles.size();
                                processing(price,quantity,vendingMachine,formatter,slotCode);
                            }
                            break;
                            case "B": 
                            if(vendingMachine.snickers.isEmpty()){
                                System.out.println("Please choose another Item. Your item selected is not available.");
                            }
                            else{
                                price = vendingMachine.snickers.peek().getPrice();
                                quantity = vendingMachine.snickers.size();
                                processing(price,quantity,vendingMachine,formatter,slotCode);
                            }
                            break;
                            case "C": 
                            if(vendingMachine.MnM.isEmpty()){
                                System.out.println("Please choose another Item. Your item selected is not available.");
                            }
                            else{
                                price = vendingMachine.MnM.peek().getPrice();
                                quantity = vendingMachine.MnM.size();
                                processing(price,quantity,vendingMachine,formatter,slotCode);
                            }
                            break;
                        case "Q":
                            System.out.println("");
                        break;
                        default:
                            System.out.println("choose from the list.");
                            break;    
                    }
                } 
            break;    
            case "Q":
                System.out.println("Thank you for using the vending Machine.");
                System.out.println("you have a good day!");
                System.exit(0);
        }  
            
    }      
        
   }
        
        
 }


